#include "DCTimsLine.h"
#include "Board.h"
#include "Player.h"
using namespace std;

DCTimsLine::DCTimsLine(int index, Board *board ):Square(index,"DC Tims Line",board){

}

DCTimsLine::~DCTimsLine(){}

void DCTimsLine::autoAction(Player *player){
}
