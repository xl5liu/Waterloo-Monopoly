

#include "View.h"

View::View(){}

View::~View(){}
